var n = a;
SKA = y;
var L = xyz;
var xxx = function FAFA(VAR1) {
	var VAR2 = 0;
	VAR3 = fafa4+VAR2+VAR1;
	return true;
};
status.show(bar);
 
console.log(xyz, "todo: ", params);
this.leaveMeAlone();
done("");
var obj = {
	type1: String,
	type2: Number,
	customType: number,
	customValue: n+L,
	run: function(){
		return xxx();
	}
};
obj.run();